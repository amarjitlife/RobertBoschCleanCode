#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];
	// void (*dance)();
} Human;

void doBhangra() { printf("\nDance: Oyee Hoyeee!!!..."); }
void doHipHop()  { printf("\nDance: Hip Hop!!!..."); }

void playWithHuman() {
	Human gabbar = { 420, "Gabbar Singh" };

	// Human gabbar = { 420, "Gabbar Singh", doBhangra };
	printf("\nID : %d", gabbar.id );
	printf("\nID : %s", gabbar.name );
	gabbar.dance();

	Human basanti = { 100, "Basanti", doHipHop };
	printf("\nID : %d", basanti.id );
	printf("\nID : %s", basanti.name );
	basanti.dance();
}

int main() {
	playWithHuman();
}

