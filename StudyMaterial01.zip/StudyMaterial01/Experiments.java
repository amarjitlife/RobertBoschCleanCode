
package learnDesign;

//_______________________________________________________

interface Superpower {
	public void fly();
	public void saveWorld();
}

class Spiderman implements Superpower {
	public void fly() 			{ System.out.println("Fly Like Spiderman!"); }
	public void saveWorld() 	{ System.out.println("SaveWorld Like Spiderman!"); }	
}

class Superman implements Superpower {
	public void fly() 			{ System.out.println("Fly Like Superman!"); }
	public void saveWorld() 	{ System.out.println("SaveWorld Like Superman!"); }	
}

class Wonderwoman implements Superpower {
	public void fly() 			{ System.out.println("Fly Like Wonderwoman!"); }
	public void saveWorld() 	{ System.out.println("SaveWorld Like Wonderwoman!"); }	
}

class HanumanJi implements Superpower {
	public void fly() 			{ System.out.println("Fly Like HanumanJi!"); }
	public void saveWorld() 	{ System.out.println("SaveWorld Like HanumanJi!"); }	
}

//_______________________________________________________
//Using Mechanism
//		Inhertance
// class Human extends Superman {
// class Human extends Wonderwoman {

class Human extends Spiderman {
	public void fly() 			{ super.fly(); 		 }//{ System.out.println("Fly Like Human!"); }
	public void saveWorld() 	{ super.saveWorld(); }//{ System.out.println("SaveWorld Like Human!"); }	
}

//_______________________________________________________
//Using Mechanism
//		Composition

// Composition Is Equivalent To Inheritance
class HumanBetter {
	// Spiderman power = new Spiderman();
	// Superman power = new Superman();
	Wonderwoman power = new Wonderwoman();
	void fly() 			{ power.fly(); 		 }//{ System.out.println("Fly Like Human!"); }
	void saveWorld() 	{ power.saveWorld(); }//{ System.out.println("SaveWorld Like Human!"); }	
}



//_______________________________________________________
//Using Mechanism
//		Composition

// Composition Is Better Than To Inheritance
//		
class HumanBest {
	Superpower power = null;
	void fly() 			{ if (power != null) power.fly(); 		 }//{ System.out.println("Fly Like Human!"); }
	void saveWorld() 	{ if (power != null) power.saveWorld(); }//{ System.out.println("SaveWorld Like Human!"); }	
}

//_______________________________________________________
//_______________________________________________________

public class Experiments {
	public static void playWithPowers() {
		Spiderman s = new Spiderman();
		s.fly();
		s.saveWorld();
	}

	public static void playWithHuman() {
		System.out.println("\nHuman...");
		Human h = new Human();
		h.fly();
		h.saveWorld();
	}

	public static void playWithHumanBetter() {
		System.out.println("\nHumanBetter...");
		HumanBetter h = new HumanBetter();
		h.fly();
		h.saveWorld();
	}

	public static void playWithHumanBest() {
		System.out.println("\nHumanBest...");
		HumanBest h = new HumanBest();

		h.power = new Spiderman();
		h.fly();
		h.saveWorld();

		h.power = new Superman();
		h.fly();
		h.saveWorld();

		h.power = new Wonderwoman();
		h.fly();
		h.saveWorld();

		h.power = new HanumanJi();
		h.fly();
		h.saveWorld();
	}

	public static void main( String[] args ) {
		System.out.println("\nFunction: playWithPowers");
		playWithPowers();
		
		System.out.println("\nFunction: playWithHuman");
		playWithHuman();

		System.out.println("\nFunction: playWithHumanBetter");
		playWithHumanBetter();
		
		System.out.println("\nFunction: playWithHumanBest");
		playWithHumanBest();

		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
	}
}

