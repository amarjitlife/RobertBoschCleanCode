#include <iostream> // Includes the input/output stream library

int main() { // The main function, where program execution begins
    std::cout << "Hello, World!" << std::endl; // Prints "Hello, World!" to the console
    return 0; // Indicates successful program execution
}

