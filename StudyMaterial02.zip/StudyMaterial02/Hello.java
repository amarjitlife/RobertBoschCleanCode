/*
javac Hello.java -d ClassFiles/
java -cp ClassFiles/ examples.Hello
*/

package examples;

public class Hello {
	public static void main( String[] args ) {
		System.out.println("Hello World!!!");
	}
}
