#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

//_________________________________________________________

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangra() { printf("\nDance: Oyee Hoyeee!!!..."); }
void doHipHop()  { printf("\nDance: Hip Hop!!!..."); }

void playWithHuman() {
	// Human gabbar = { 420, "Gabbar Singh" };

	Human gabbar = { 420, "Gabbar Singh", doBhangra };
	printf("\nID : %d", gabbar.id );
	printf("\nID : %s", gabbar.name );
	gabbar.dance();

	Human basanti = { 100, "Basanti", doHipHop };
	printf("\nID : %d", basanti.id );
	printf("\nID : %s", basanti.name );
	basanti.dance();
}

//_________________________________________________________
// Drivent By Defination
//              Type Defination

// Type Safe Code
int sum( int a, int b ) {
        signed int sum;

        if ( ( b > 0 ) && a > ( INT_MAX - b ) ||
                 ( b < 0 ) && a < ( INT_MIN - b ) ) {
                printf("\nCan't Calcualate Valid Arithmatic Sum");
                exit( 1 );
        } else {
                sum = a + b; 
                return sum;
        }
}

//_________________________________________________________

// Function Type (int, int) -> int
int summation( int x, int y ) { return x + y; }
int substraction( int x, int y ) { return x - y; }

// Function Type (int, int, (int, int) -> int ) -> int
int calculator( int x, int y, int (*operation)(int ,int )) {
	return operation( x, y );
}

void playWithCalculator() {
	int x = 40, y = 10, result = 0;
	result = calculator( x, y, summation );
	printf("\nResult %d ", result);

	result = calculator( x, y, substraction );
	printf("\nResult %d ", result);
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

int main() {
	playWithHuman();
}

