
package learnDesign;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//_________________________________________________________________________
//_________________________________________________________________________


// package refactoring_guru.template_method.example.networks;

/**
 * EN: Class of social network
 *
 * RU: Класс социальной сети.
 */
class Facebook extends Network {
    public Facebook(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    public boolean logIn(String userName, String password) {
        System.out.println("\nChecking user's parameters");
        System.out.println("Name: " + this.userName);
        System.out.print("Password: ");
        for (int i = 0; i < this.password.length(); i++) {
            System.out.print("*");
        }
        simulateNetworkLatency();
        System.out.println("\n\nLogIn success on Facebook");
        return true;
    }

    public boolean sendData(byte[] data) {
        boolean messagePosted = true;
        if (messagePosted) {
            System.out.println("Message: '" + new String(data) + "' was posted on Facebook");
            return true;
        } else {
            return false;
        }
    }

    public void logOut() {
        System.out.println("User: '" + userName + "' was logged out from Facebook");
    }

    private void simulateNetworkLatency() {
        try {
            int i = 0;
            System.out.println();
            while (i < 10) {
                System.out.print(".");
                Thread.sleep(500);
                i++;
            }
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
}


//_________________________________________________________________________
//_________________________________________________________________________


// package refactoring_guru.template_method.example.networks;

/**
 * EN: Base class of social network.
 *
 * RU: Базовый класс социальной сети.
 */

 abstract class Network {
    String userName;
    String password;

    Network() {}

    /**
     * EN: Publish the data to whatever network.
     *
     * RU: Публикация данных в любой сети.
     */
    public boolean post(String message) {
        // EN: Authenticate before posting. Every network uses a different
        // authentication method.
        //
        // RU: Проверка данных пользователя перед постом в соцсеть. Каждая сеть
        // для проверки использует разные методы.
        if (logIn(this.userName, this.password)) {
            // EN: Send the post data.
            //
            // RU: Отправка данных.
            boolean result =  sendData(message.getBytes());
            logOut();
            return result;
        }
        return false;
    }

    abstract boolean logIn(String userName, String password);
    abstract boolean sendData(byte[] data);
    abstract void logOut();
}

//_________________________________________________________________________
//_________________________________________________________________________


// package refactoring_guru.template_method.example.networks;

/**
 * EN: Class of social network
 *
 * RU: Класс социальной сети.
 */
class Twitter extends Network {

    public Twitter(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    public boolean logIn(String userName, String password) {
        System.out.println("\nChecking user's parameters");
        System.out.println("Name: " + this.userName);
        System.out.print("Password: ");
        for (int i = 0; i < this.password.length(); i++) {
            System.out.print("*");
        }
        simulateNetworkLatency();
        System.out.println("\n\nLogIn success on Twitter");
        return true;
    }

    public boolean sendData(byte[] data) {
        boolean messagePosted = true;
        if (messagePosted) {
            System.out.println("Message: '" + new String(data) + "' was posted on Twitter");
            return true;
        } else {
            return false;
        }
    }

    public void logOut() {
        System.out.println("User: '" + userName + "' was logged out from Twitter");
    }

    private void simulateNetworkLatency() {
        try {
            int i = 0;
            System.out.println();
            while (i < 10) {
                System.out.print(".");
                Thread.sleep(500);
                i++;
            }
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
}

//_________________________________________________________________________
//_________________________________________________________________________


// package refactoring_guru.template_method.example;

// import refactoring_guru.template_method.example.networks.Facebook;
// import refactoring_guru.template_method.example.networks.Network;
// import refactoring_guru.template_method.example.networks.Twitter;

// import java.io.BufferedReader;
// import java.io.IOException;
// import java.io.InputStreamReader;

/**
 * EN: Demo class. Everything comes together here.
 *
 * RU: Демо-класс. Здесь всё сводится воедино.
 */
class B09TemplateMethod {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Network network = null;
        System.out.print("Input user name: ");
        String userName = reader.readLine();
        System.out.print("Input password: ");
        String password = reader.readLine();

        // EN: Enter the message.
        //
        // RU: Вводим сообщение.
        System.out.print("Input message: ");
        String message = reader.readLine();

        System.out.println("\nChoose social network for posting message.\n" +
                "1 - Facebook\n" +
                "2 - Twitter");
        int choice = Integer.parseInt(reader.readLine());

        // EN: Create proper network object and send the message.
        //
        // RU: Создаем сетевые объекты и публикуем пост.
        if (choice == 1) {
            network = new Facebook(userName, password);
        } else if (choice == 2) {
            network = new Twitter(userName, password);
        }
        network.post(message);
    }
}

