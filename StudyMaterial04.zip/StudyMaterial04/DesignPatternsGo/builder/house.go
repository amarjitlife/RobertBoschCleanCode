package main

type House struct {
	windowType string
	doorType   string
	floor      int
}
