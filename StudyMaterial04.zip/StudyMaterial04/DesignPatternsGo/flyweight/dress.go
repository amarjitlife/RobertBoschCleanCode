package main

type Dress interface {
	getColor() string
}
