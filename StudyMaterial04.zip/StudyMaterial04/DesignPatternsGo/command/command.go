package main

type Command interface {
	execute()
}
