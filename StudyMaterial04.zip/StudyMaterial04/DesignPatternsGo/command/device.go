package main

type Device interface {
	on()
	off()
}
