package main

type Computer interface {
	InsertIntoLightningPort()
}
