package main

type Printer interface {
	PrintFile()
}
