package main

type Computer interface {
	Print()
	SetPrinter(Printer)
}
