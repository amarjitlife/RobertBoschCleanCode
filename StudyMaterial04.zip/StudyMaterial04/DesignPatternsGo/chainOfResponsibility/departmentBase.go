package main

type DepartmentBase struct {
	nextDepartment Department
}
