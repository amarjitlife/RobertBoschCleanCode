package main

type IPizza interface {
	getPrice() int
}
