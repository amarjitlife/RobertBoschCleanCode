package main

type User struct {
	name string
	age  int
}
