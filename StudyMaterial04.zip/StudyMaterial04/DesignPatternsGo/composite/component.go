package main

type Component interface {
	search(string)
}
