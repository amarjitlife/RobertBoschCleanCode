package main

type NikeShoe struct {
	Shoe
}
