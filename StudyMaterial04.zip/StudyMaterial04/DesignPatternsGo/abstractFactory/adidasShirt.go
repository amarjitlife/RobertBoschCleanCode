package main

type AdidasShirt struct {
	Shirt
}
