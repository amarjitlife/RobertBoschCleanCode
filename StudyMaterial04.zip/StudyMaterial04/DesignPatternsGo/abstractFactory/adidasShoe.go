package main

type AdidasShoe struct {
	Shoe
}
