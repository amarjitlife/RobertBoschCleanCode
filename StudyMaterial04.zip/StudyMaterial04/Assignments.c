__________________________________________________

DAY 01
__________________________________________________

	ASSIGNMENT A1: Practice Ideas and Code

	ASSIGNMENT A2: Readinga and Practice Assignment
		Read and Practice Code Examples From Following Chapters
			Chapter 10: Better Structures
			Chatper 11: Object Oriented Programming In C
	
			Reference Book: 21st Century C, 2nd Edition
__________________________________________________

DAY 02
__________________________________________________

	ASSIGNMENT A1: Reading and Practice Assignment
		Read and Practice Code Examples From Following Chapters
			Chatper 11: Object Oriented Programming In C
	
			Reference Book: 21st Century C, 2nd Edition

	ASSIGNMENT A1: Code Design Ideas and Principles Discussed Today

		Read and Practice Code For Design Principles, Practices
			DesignPrinciplesNotes.pdf

__________________________________________________

DAY 03
__________________________________________________

	ASSIGNMENT A1: Code Design Ideas and Principles Discussed Today


__________________________________________________

DAY 04
__________________________________________________

	ASSIGNMENT A1: Code Design Ideas and Principles Discussed Today
		Read Book : Design Patterns By GoF
		
		The C++ Programming Language, 4th Edition
			Bjarne Stratroup
		C++ Primer By Lipman

		The C Programming Language, 2nd Edition
			K & R 

		Effective C++
		More Effective C++
		Effective Modern C++ 

		Clean Code Book

	FUTURE AND ADVANCE LEARNERS
		Structure and Interpretation Of Computer Program
		MIT Publication

__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________

https://github.com/amarjitlife/RobertBoschCleanCode
https://github.com/amarjitlife/RobertBoschCleanCode
https://github.com/amarjitlife/RobertBoschCleanCode

Download: 
	StudyMaterial01.zip
	StudyMaterial02.zip

__________________________________________________


https://codeshare.io/adk98K
https://codeshare.io/adk98K
https://codeshare.io/adk98K
https://codeshare.io/adk98K

__________________________________________________

